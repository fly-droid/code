﻿namespace Countdowngameprogram
{
    partial class frmCountdowngameprogram
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnVowel = new System.Windows.Forms.Button();
            this.btnConsonant = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(12, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(458, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // btnVowel
            // 
            this.btnVowel.Location = new System.Drawing.Point(69, 160);
            this.btnVowel.Name = "btnVowel";
            this.btnVowel.Size = new System.Drawing.Size(139, 35);
            this.btnVowel.TabIndex = 1;
            this.btnVowel.Text = "Vowel please, Carol";
            this.btnVowel.UseVisualStyleBackColor = true;
            this.btnVowel.Click += new System.EventHandler(this.btnVowel_Click);
            // 
            // btnConsonant
            // 
            this.btnConsonant.Location = new System.Drawing.Point(273, 160);
            this.btnConsonant.Name = "btnConsonant";
            this.btnConsonant.Size = new System.Drawing.Size(111, 34);
            this.btnConsonant.TabIndex = 2;
            this.btnConsonant.Text = "Consonant please";
            this.btnConsonant.UseVisualStyleBackColor = true;
            this.btnConsonant.Click += new System.EventHandler(this.btnConsonant_Click);
            // 
            // frmCountdowngameprogram
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 226);
            this.Controls.Add(this.btnConsonant);
            this.Controls.Add(this.btnVowel);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmCountdowngameprogram";
            this.Text = "Countdown Letters";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnVowel;
        private System.Windows.Forms.Button btnConsonant;
    }
}