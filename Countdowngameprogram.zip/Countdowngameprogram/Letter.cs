﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Countdowngameprogram
{
    internal class Letter
    {
        
        private static Random r = new Random();
        private static int NumberLetters = 0;

      
        private const int initialGap = 24;
        private const int gapBetweenLetters = 54;
        private const string Vowels = "AEIOU";
        private const string Consonants = "BCDFGHJKLMNPQRSTVWXYZ";

        private bool ifVowel;
        private char choice;

        public bool IfVowel
        {
            set
            {
                ifVowel = value;
                choice = GenerateLetter();
            }
        }

        private char Choice
        {
            get { return choice; }
        }


        public Letter()
        {
            NumberLetters++;
        }

        private char GenerateLetter()
        {
            if (ifVowel)
            {
                return Vowels[r.Next(0, Vowels.Length)];
            }
            else
            {
                return Consonants[r.Next(0, Consonants.Length)];
            }
        }

        public void AddForm(GroupBox grp)
        {
            TextBox txtBox = new TextBox
            {
                Width = 40,
                Height = 40,
                TextAlign = HorizontalAlignment.Center,
                Font = new System.Drawing.Font("Arial", 18),
                Text = Choice.ToString(),
                ReadOnly = true
            };
            int leftPosition = initialGap + (NumberLetters - 1) * gapBetweenLetters;
            txtBox.Left = leftPosition;
            txtBox.Top = 20;

            grp.Controls.Add(txtBox);
        }
    }
}
