﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Countdowngameprogram
{
    public partial class frmCountdowngameprogram : Form
    {
        public frmCountdowngameprogram()
        {
            InitializeComponent();
        }

        private void CheckNumberLetters()
        {
            if (groupBox1.Controls.Count == 9)
            {
                btnVowel.Enabled = false;
                btnConsonant.Enabled = false;
                MessageBox.Show("Countdown clock has started!", "Game Over");
            }
        }

        private void btnVowel_Click(object sender, EventArgs e)
        {
            var nextLetter = new Letter
            {
                IfVowel = true
            };
            nextLetter.AddForm(groupBox1);

            CheckNumberLetters();
        }

        private void btnConsonant_Click(object sender, EventArgs e)
        {
            var nextLetter = new Letter
            {
                IfVowel = false
            };
            nextLetter.AddForm(groupBox1);
            CheckNumberLetters();
        }
    }
}
