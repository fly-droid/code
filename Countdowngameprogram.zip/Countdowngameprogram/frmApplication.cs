﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Visual_C_Sharp
{
    public partial class frmApplication : Form
    {
        public frmApplication()
        {
            InitializeComponent();
        }

        private bool ValidateControls(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is GroupBox)
                {
                    if (!ValidateControls(control.Controls))
                    {
                        return false;
                    }
                }
                else if (control is TextBox || control is ComboBox)
                {
                    if (string.IsNullOrWhiteSpace(control.Text))
                    {
                        MessageBox.Show("Please fill in all", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        control.Focus();
                        return false;
                    }
                }
            }
            return true;
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            // close 
            this.Close();
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
              if (ValidateControls(this.Controls))
            {
                MessageBox.Show("All fields are filled in.");
            }
        }
    }
}
