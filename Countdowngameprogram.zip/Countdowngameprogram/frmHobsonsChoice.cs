﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Visual_C_Sharp
{
    public partial class frmHobsonsChoice : Form
    {
        public frmHobsonsChoice()
        {
            InitializeComponent();
        }

        private void btnLongestName_Click(object sender, EventArgs e)
        {
            string longestName = ""; 

            
            foreach (string item in cmbDate.Items)
            {
               
                if (item.Length > longestName.Length)
                {
                    longestName = item;
                }
            }

            
            MessageBox.Show("The longest name is: " + longestName);
        }
    }

}
